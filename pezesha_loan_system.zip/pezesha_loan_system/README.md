# 🏦 Pezesha Loan Default Prediction System

An AI-powered risk scoring system that predicts whether a new borrower is likely to default, with plain-English explanations for every score.

---

## 📁 Folder Structure

```
pezesha_loan_system/
│
├── data/
│   └── historical_loans.csv       ← your training data goes here
│
├── models/                        ← auto-created when you train
│   ├── xgb_model.pkl
│   ├── fill_medians.json
│   ├── feature_columns.json
│   └── shap_explainer.pkl
│
├── src/
│   ├── generate_sample_data.py    ← creates fake training data to get started
│   ├── preprocess.py              ← data cleaning & feature engineering
│   ├── train_model.py             ← trains + saves the XGBoost model
│   ├── explain.py                 ← converts SHAP values to English sentences
│   └── app.py                     ← Streamlit dashboard (the web interface)
│
├── requirements.txt               ← all Python libraries needed
└── README.md                      ← this file
```

---

## ⚙️ Setup — Follow These Steps in Order

### Step 1 — Make sure you have Python installed

Open a terminal (Command Prompt on Windows, Terminal on Mac/Linux) and type:

```bash
python --version
```

You need Python 3.10 or newer. Download it free from https://python.org if needed.

---

### Step 2 — Navigate to the project folder

```bash
cd path/to/pezesha_loan_system
```

For example: `cd C:\Users\YourName\Desktop\pezesha_loan_system`

---

### Step 3 — Install all required libraries

This installs everything in one command:

```bash
pip install -r requirements.txt
```

This will take 1–3 minutes. You'll see a lot of text — that's normal.

**What each library does:**
- `pandas` — reads and cleans your CSV data
- `numpy` — handles numbers and arrays
- `scikit-learn` — splits data into train/test sets, measures accuracy
- `xgboost` — the machine learning model (excellent for tabular data)
- `shap` — explains *why* each borrower got their score
- `streamlit` — builds the web dashboard with no web development needed

---

### Step 4 — Create sample training data (first time only)

If you don't have real historical loan data yet, run this to generate 2,000 realistic fake borrowers so you can test the whole system:

```bash
python src/generate_sample_data.py
```

This creates `data/historical_loans.csv`.

**Using your own real data?** Replace `data/historical_loans.csv` with your file. It must have these exact column names:

| Column | Example values |
|---|---|
| `borrower_id` | PEZ10001 |
| `loan_amount` | 15000 |
| `loan_date` | 2023-04-15 |
| `business_type` | retail_shop |
| `business_location` | Nairobi |
| `years_in_business` | 3.5 |
| `repayment_history` | on_time / late / defaulted |
| `mobile_money_activity_score` | 72.5 |

---

### Step 5 — Train the model

```bash
python src/train_model.py
```

This will:
1. Load and clean your CSV
2. Engineer features (encode categories, handle missing values, etc.)
3. Train an XGBoost model
4. Print the model's accuracy (ROC-AUC score — higher is better, aim for >0.75)
5. Save the model to the `models/` folder

You only need to re-run this when you have new historical data.

---

### Step 6 — Launch the web dashboard

```bash
streamlit run src/app.py
```

Your browser will automatically open at **http://localhost:8501**

You'll see a form where you can enter a borrower's details and instantly get:
- ✅ A risk score from 0 to 100
- 🟢 / 🟡 / 🔴 A Green / Amber / Red risk label
- 💬 The top 3 plain-English reasons behind the score

---

## 🎯 Understanding the Risk Score

| Score | Colour | Meaning |
|---|---|---|
| 0 – 34 | 🟢 GREEN | Low risk — proceed with standard terms |
| 35 – 64 | 🟡 AMBER | Medium risk — consider reduced amount or guarantor |
| 65 – 100 | 🔴 RED | High risk — escalate for manual review |

---

## 🔁 Using Your Own CSV (Custom Path)

```bash
python src/train_model.py data/your_real_data.csv
```

---

## ❓ Troubleshooting

**"ModuleNotFoundError"** → Run `pip install -r requirements.txt` again

**"No trained model found"** → Run `python src/train_model.py` first

**Low accuracy (AUC < 0.65)** → You likely need more historical data or to check that `repayment_history` values are spelled correctly (must be exactly: `on_time`, `late`, `defaulted`)

**Port 8501 already in use** → Run `streamlit run src/app.py --server.port 8502`

---

## 🔐 Security Note

This dashboard is designed for internal use on a private network. Before exposing it to the internet, consult your IT team to add authentication.

---

*Built for Pezesha · XGBoost + SHAP · Streamlit*
